public abstract class Bill implements Payable
{
    private String vendorName;

    public Bill(String s)
    {
        vendorName = s;
    }

    public abstract double getPaymentAmount();

    @Override
    public String toString()
    {
        return "Company Name - " + vendorName;
    }
}

