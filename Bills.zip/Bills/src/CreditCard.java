import java.util.*;
public class CreditCard extends Bill
{
    private double charges;
    private double credit;
    private double payment;


    public CreditCard(String s, double cred, double charge)
    {
        super(s);
        credit = cred;
        charges = charge;

    }

    public double getPaymentAmount()
    {
        payment = charges - credit;

        return payment;

    }

    @Override
    public String toString()
    {
        String str;
        if(payment < 0)
        {
            str = "Credit Left: ";
        }
        else
        {
           str = "Total Due: ";
        }
        return String.format("Credit Card bill: \n" + super.toString() +
                        "\nCredit - $%,.2f\nCharges - $%,.2f\n" + str + "$%,.2f"
                ,credit,charges,Math.abs(payment));
    }
}
