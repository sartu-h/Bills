public class Mortgage extends Bill
{
    private double principal;
    private double interest;
    private double taxes;
    private double insurance;
    private double payment;

    public Mortgage(String s, double p, double i, double t, double ins)
    {
        super(s);
        principal = p;
        interest = i;
        taxes = t;
        insurance = ins;
    }

    public double getPaymentAmount()
    {
        payment = principal + insurance + taxes + insurance;

        return payment;
    }

    @Override
    public String toString()
    {
        return String.format("Mortgage bill: \n" + super.toString() +
                "\nPrincipal - $%,.2f\nInterest - $%,.2f\nTaxes - $%,.2f\nInsurance - $%,.2f\nTotal Due: $%,.2f"
                ,principal,interest,taxes,insurance,payment);
    }
}
