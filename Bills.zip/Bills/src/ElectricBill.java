public class ElectricBill extends Bill
{
    private double baseCharge;
    private double costPerKwatt;
    private double kWattConsumed;
    private double payment;

    public ElectricBill(String s, double bs, double cpk, double kwc)
    {
        super(s);
        baseCharge = bs;
        costPerKwatt = cpk;
        kWattConsumed = kwc;
    }

    public double getPaymentAmount()
    {
        payment = baseCharge + (costPerKwatt * kWattConsumed);

        return payment;
    }

    @Override
    public String toString()
    {
        return String.format("Electric bill: \n" + super.toString() +
                        "\nBase Charge - $%,.2f\nCost per KiloWatt - $%.2f\nKiloWatt Consumed - %.2f\nTotal Due: $%,.2f"
                ,baseCharge,costPerKwatt,kWattConsumed,payment);
    }
}
