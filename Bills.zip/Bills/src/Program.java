import java.util.*;
public class Program
{

    public Mortgage selectMortgage()
    {
        Scanner kb = new Scanner(System.in);

        System.out.println("What is the name of the Mortgage company?");
        String vendorName = kb.nextLine();

        System.out.println("How much did you loan?");
        double principal = kb.nextDouble();
        kb.nextLine();

        System.out.println("What was the interest?");
        double interest = kb.nextDouble();
        kb.nextLine();

        System.out.println("Please enter the amount of tax: ");
        double tax = kb.nextDouble();
        kb.nextLine();

        System.out.println("Enter the price for insurance: ");
        double insurance = kb.nextDouble();
        kb.nextLine();

        return new Mortgage(vendorName,principal,interest,tax,insurance);

    }

    public CreditCard selectCreditCard()
    {
        Scanner kb = new Scanner(System.in);

        System.out.println("What is the name of the Credit Card company?");
        String vendorName = kb.nextLine();

        System.out.println("How much credit is on your card?");
        double credit = kb.nextDouble();
        kb.nextLine();

        System.out.println("Please enter the amount spent on the card: ");
        double charge = kb.nextDouble();
        kb.nextLine();

        return new CreditCard(vendorName,credit,charge);

    }

    public ElectricBill selectElectricBill()
    {
        Scanner kb = new Scanner(System.in);

        System.out.println("What is the name of the Electric Company company?");
        String vendorName = kb.nextLine();

        System.out.println("What is the base charge?");
        double baseCharge = kb.nextDouble();
        kb.nextLine();

        System.out.println("What's the cost per KiloWatt?");
        double cost = kb.nextDouble();
        kb.nextLine();

        System.out.println("How much KiloWatt was consumed?");
        double consumed = kb.nextDouble();
        kb.nextLine();

        return new ElectricBill(vendorName,baseCharge,cost,consumed);

    }
}
