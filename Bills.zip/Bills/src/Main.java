import java.util.*;

public class Main
{
    public static void main(String[] args)
    {
        Program run = new Program();
        ArrayList<Bill>billList = new ArrayList<>();
        double total = 0;

        System.out.println("Welcome to the Bill Simulation!");
        System.out.println("Please pick which bill you'd like to enter: \n" +
                "Mortgage, Credit Card, Electric Bill.");
        Scanner kb = new Scanner(System.in);
        String input = kb.nextLine();

        while(!input.toLowerCase().contains("done"))
        {
            if (input.toLowerCase().contains("mortgage"))
            {
                Mortgage mortgage;
                mortgage = run.selectMortgage();
                billList.add(mortgage);
                total += mortgage.getPaymentAmount();
            }

            if (input.toLowerCase().contains("credit card"))
            {
                CreditCard card;
                card = run.selectCreditCard();
                billList.add(card);
                if(card.getPaymentAmount() > 0)
                {
                    total += card.getPaymentAmount();
                }
            }

            if (input.toLowerCase().contains("electric bill"))
            {
                ElectricBill electricBill;
                electricBill = run.selectElectricBill();
                billList.add(electricBill);
                total += electricBill.getPaymentAmount();
            }

            System.out.println("If you're all done please enter done, otherwise select another bill.");
            input = kb.nextLine();
        }

        System.out.println("Here's your full bill:\n\n");

        for(int i = 0; i < billList.size(); i++)
        {
            System.out.println(billList.get(i).toString());
            System.out.println();
        }

        System.out.printf("Your total amount came out to $%,.2f",total);
    }
}